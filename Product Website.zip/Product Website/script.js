
// ==========================================================
// AURIX PRODUCT LAUNCH WEBSITE
// File: script.js
//
// BEGINNER CUSTOMIZATION GUIDE
// 1. Change LAUNCH_DATE to your launch date and time.
// 2. Change BUY_NOW_URL to your product or checkout page.
// 3. Change image paths in index.html to your own photos.
// 4. This demo form does not store or email visitor details.
// ==========================================================

document.documentElement.classList.remove("no-js");

// ==================== 1. CUSTOM SETTINGS ====================

// EDIT: Set your actual launch date and time.
// Include your timezone offset if needed.
// Example: "2026-12-25T10:00:00+05:00"
const LAUNCH_DATE = "2026-12-15T10:00:00+05:00";

// EDIT: Replace this with your real product purchase URL.
// The Buy Now button in index.html uses this setting.
const BUY_NOW_URL = "https://example.com";

// ==================== 2. MOBILE NAVIGATION ====================

const menuToggle = document.getElementById("menuToggle");
const navLinks = document.getElementById("navLinks");

function closeMenu() {
  if (!menuToggle || !navLinks) return;

  navLinks.classList.remove("open");
  menuToggle.setAttribute("aria-expanded", "false");
  menuToggle.setAttribute("aria-label", "Open navigation menu");
}

if (menuToggle && navLinks) {
  menuToggle.addEventListener("click", () => {
    const isOpen = navLinks.classList.toggle("open");

    menuToggle.setAttribute("aria-expanded", String(isOpen));
    menuToggle.setAttribute(
      "aria-label",
      isOpen ? "Close navigation menu" : "Open navigation menu"
    );
  });

  // Close the menu after someone selects a navigation link.
  navLinks.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", closeMenu);
  });

  // Close the menu if the visitor presses Escape.
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") closeMenu();
  });

  // If the screen becomes wider, reset the mobile menu.
  window.addEventListener("resize", () => {
    if (window.innerWidth > 700) closeMenu();
  });
}

// ==================== 3. PRODUCT GALLERY ====================

// The image paths are stored in data-image attributes
// on the gallery buttons in index.html.

const mainGalleryImage = document.getElementById("mainGalleryImage");
const galleryPlaceholder = document.querySelector(".gallery-placeholder");
const galleryThumbs = document.querySelectorAll(".gallery-thumb");

function setGalleryImage(imagePath, imageAlt, selectedThumb = null) {
  if (!mainGalleryImage) return;

  // Display the image again if a previous image failed to load.
  mainGalleryImage.style.display = "block";

  if (galleryPlaceholder) {
    galleryPlaceholder.style.display = "none";
  }

  mainGalleryImage.alt = imageAlt;
  mainGalleryImage.src = imagePath;

  // Show a friendly fallback if the image does not exist.
  mainGalleryImage.onerror = () => {
    mainGalleryImage.style.display = "none";

    if (galleryPlaceholder) {
      galleryPlaceholder.style.display = "grid";
    }
  };

  mainGalleryImage.onload = () => {
    mainGalleryImage.style.display = "block";

    if (galleryPlaceholder) {
      galleryPlaceholder.style.display = "none";
    }
  };

  // Update the active thumbnail.
  galleryThumbs.forEach((thumb) => {
    const isActive = thumb === selectedThumb;

    thumb.classList.toggle("active", isActive);
    thumb.setAttribute("aria-pressed", String(isActive));
  });
}

galleryThumbs.forEach((thumb) => {
  thumb.addEventListener("click", () => {
    const imagePath = thumb.dataset.image;
    const imageAlt = thumb.dataset.alt || "Product image";

    if (imagePath) {
      setGalleryImage(imagePath, imageAlt, thumb);
    }
  });
});

// ==================== 4. PRODUCT IMAGE LIGHTBOX ====================

const imageLightbox = document.getElementById("imageLightbox");
const openLightboxButton = document.getElementById("openLightbox");
const closeLightboxButton = document.getElementById("closeLightbox");
const lightboxImage = document.getElementById("lightboxImage");

function openImageViewer() {
  if (!imageLightbox || !lightboxImage || !mainGalleryImage) return;

  // Do not open an empty viewer when the main image is missing.
  if (
    mainGalleryImage.style.display === "none" ||
    !mainGalleryImage.complete ||
    mainGalleryImage.naturalWidth === 0
  ) {
    return;
  }

  lightboxImage.src = mainGalleryImage.src;
  lightboxImage.alt = mainGalleryImage.alt;

  // The native dialog provides modal behavior and Escape support.
  if (typeof imageLightbox.showModal === "function") {
    imageLightbox.showModal();
  }
}

function closeImageViewer() {
  if (imageLightbox && imageLightbox.open) {
    imageLightbox.close();
  }
}

if (openLightboxButton) {
  openLightboxButton.addEventListener("click", openImageViewer);
}

if (mainGalleryImage) {
  mainGalleryImage.addEventListener("click", openImageViewer);
}

if (closeLightboxButton) {
  closeLightboxButton.addEventListener("click", closeImageViewer);
}

// Close the viewer when the user clicks its backdrop.
if (imageLightbox) {
  imageLightbox.addEventListener("click", (event) => {
    if (event.target === imageLightbox) {
      closeImageViewer();
    }
  });
}

// ==================== 5. LAUNCH COUNTDOWN ====================

const countdownElements = {
  days: document.getElementById("days"),
  hours: document.getElementById("hours"),
  minutes: document.getElementById("minutes"),
  seconds: document.getElementById("seconds")
};

const countdownContainer = document.getElementById("countdown");
const launchDateLabel = document.getElementById("launchDateLabel");
const launchAnnouncement = document.getElementById("launchAnnouncement");

const launchTimestamp = new Date(LAUNCH_DATE).getTime();

let countdownInterval = null;

function padNumber(number) {
  return String(number).padStart(2, "0");
}

function updateCountdown() {
  if (!Number.isFinite(launchTimestamp)) {
    if (launchDateLabel) {
      launchDateLabel.textContent =
        "Please enter a valid launch date in script.js.";
    }

    if (countdownContainer) {
      countdownContainer.hidden = true;
    }

    return;
  }

  const now = Date.now();
  const remaining = launchTimestamp - now;

  // The launch date has arrived or has already passed.
  if (remaining <= 0) {
    if (countdownInterval !== null) {
      clearInterval(countdownInterval);
      countdownInterval = null;
    }

    if (countdownContainer) {
      countdownContainer.hidden = true;
    }

    if (launchDateLabel) {
      launchDateLabel.textContent = "The launch moment is here.";
    }

    if (launchAnnouncement) {
      launchAnnouncement.hidden = false;
    }

    return;
  }

  const days = Math.floor(remaining / (1000 * 60 * 60 * 24));
  const hours = Math.floor(
    (remaining / (1000 * 60 * 60)) % 24
  );
  const minutes = Math.floor(
    (remaining / (1000 * 60)) % 60
  );
  const seconds = Math.floor(
    (remaining / 1000) % 60
  );

  if (countdownElements.days) {
    countdownElements.days.textContent = padNumber(days);
  }

  if (countdownElements.hours) {
    countdownElements.hours.textContent = padNumber(hours);
  }

  if (countdownElements.minutes) {
    countdownElements.minutes.textContent = padNumber(minutes);
  }

  if (countdownElements.seconds) {
    countdownElements.seconds.textContent = padNumber(seconds);
  }

  if (launchDateLabel) {
    const formattedDate = new Date(launchTimestamp).toLocaleString(
      undefined,
      {
        year: "numeric",
        month: "long",
        day: "numeric",
        hour: "numeric",
        minute: "2-digit"
      }
    );

    launchDateLabel.textContent = `Launch date: ${formattedDate}`;
  }
}

// Update immediately, then refresh once per second.
updateCountdown();

if (launchTimestamp > Date.now()) {
  countdownInterval = setInterval(updateCountdown, 1000);
}

// ==================== 6. EMAIL FORM VALIDATION ====================

const notifyForm = document.getElementById("notifyForm");
const visitorName = document.getElementById("visitorName");
const visitorEmail = document.getElementById("visitorEmail");
const emailConsent = document.getElementById("emailConsent");
const formMessage = document.getElementById("formMessage");

function showFormMessage(message, type) {
  if (!formMessage) return;

  formMessage.textContent = message;
  formMessage.className = `form-message ${type}`;
}

function isValidEmail(email) {
  // A basic browser-side email format check.
  // Real systems must also verify addresses server-side.
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

if (notifyForm) {
  notifyForm.addEventListener("submit", (event) => {
    event.preventDefault();

    if (!visitorName || !visitorEmail || !emailConsent) return;

    const name = visitorName.value.trim();
    const email = visitorEmail.value.trim();

    // Reset earlier validation indicators.
    visitorName.removeAttribute("aria-invalid");
    visitorEmail.removeAttribute("aria-invalid");

    if (name.length < 2) {
      visitorName.setAttribute("aria-invalid", "true");

      showFormMessage(
        "Please enter your name (at least 2 characters).",
        "error"
      );

      visitorName.focus();
      return;
    }

    if (name.length > 80) {
      visitorName.setAttribute("aria-invalid", "true");

      showFormMessage(
        "Your name must be 80 characters or fewer.",
        "error"
      );

      visitorName.focus();
      return;
    }

    if (!isValidEmail(email) || email.length > 254) {
      visitorEmail.setAttribute("aria-invalid", "true");

      showFormMessage(
        "Please enter a valid email address.",
        "error"
      );

      visitorEmail.focus();
      return;
    }

    if (!emailConsent.checked) {
      showFormMessage(
        "Please agree to receive launch updates before continuing.",
        "error"
      );

      emailConsent.focus();
      return;
    }

    // IMPORTANT:
    // This is only a front-end demonstration.
    // It does not save the details, send an email, or subscribe anyone.
    //
    // For a real launch list, send the details securely to a backend
    // or a reputable email marketing service with the visitor's consent.
    //
    // Never put private API keys or secret credentials in this file.

    showFormMessage(
      `Thanks, ${name}! The form passed validation. ` +
      "This demo does not save your details or send an email. " +
      "Connect an email service to complete your subscription.",
      "success"
    );

    // No reset here, so visitors can see what they entered.
  });

  // Remove error styling when the visitor edits a field.
  [visitorName, visitorEmail].forEach((field) => {
    if (!field) return;

    field.addEventListener("input", () => {
      field.removeAttribute("aria-invalid");

      if (formMessage) {
        formMessage.textContent = "";
        formMessage.className = "form-message";
      }
    });
  });
}

// ==================== 7. INTERACTIVE COLOR SELECTION ====================

const colorButtons = document.querySelectorAll(".color-dot");
const selectedColor = document.getElementById("selectedColor");

colorButtons.forEach((button) => {
  button.addEventListener("click", () => {
    colorButtons.forEach((otherButton) => {
      const isSelected = otherButton === button;

      otherButton.classList.toggle("selected", isSelected);
      otherButton.setAttribute("aria-pressed", String(isSelected));
    });

    if (selectedColor) {
      selectedColor.textContent = button.dataset.color || "Selected color";
    }

    // NOTE:
    // This demo updates the selected color label only.
    // To change the product photo too, associate each color with
    // its own image and update mainGalleryImage.src here.
  });
});

// ==================== 8. FAQ ACCORDION ====================

const faqQuestions = document.querySelectorAll(".faq-question");

faqQuestions.forEach((question) => {
  question.addEventListener("click", () => {
    const currentlyExpanded =
      question.getAttribute("aria-expanded") === "true";

    const answer = question.closest(".faq-item")
      ?.querySelector(".faq-answer");

    // Close all FAQ answers first, so only one is open at a time.
    faqQuestions.forEach((otherQuestion) => {
      otherQuestion.setAttribute("aria-expanded", "false");

      const otherAnswer = otherQuestion
        .closest(".faq-item")
        ?.querySelector(".faq-answer");

      if (otherAnswer) {
        otherAnswer.hidden = true;
      }
    });

    // Open the selected answer if it was previously closed.
    if (!currentlyExpanded && answer) {
      question.setAttribute("aria-expanded", "true");
      answer.hidden = false;
    }
  });
});

// ==================== 9. ENTRANCE ANIMATIONS ====================

// Respect the visitor's reduced-motion accessibility preference.
const prefersReducedMotion = window.matchMedia(
  "(prefers-reduced-motion: reduce)"
).matches;

const revealElements = document.querySelectorAll(".reveal");

if ("IntersectionObserver" in window && !prefersReducedMotion) {
  const revealObserver = new IntersectionObserver(
    (entries, observer) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      });
    },
    {
      threshold: 0.12,
      rootMargin: "0px 0px -30px 0px"
    }
  );

  revealElements.forEach((element) => {
    revealObserver.observe(element);
  });
} else {
  // Fallback for browsers without IntersectionObserver,
  // or visitors who prefer reduced motion.
  revealElements.forEach((element) => {
    element.classList.add("is-visible");
  });
}

// ==================== 10. PURCHASE LINK ====================

// Set the Buy Now button URL from the setting at the top of this file.
const buyNowButton = document.getElementById("buyNowButton");

if (buyNowButton) {
  buyNowButton.href = BUY_NOW_URL;
}

// ==================== 11. AUTOMATIC COPYRIGHT YEAR ====================

const currentYear = document.getElementById("currentYear");

if (currentYear) {
  currentYear.textContent = new Date().getFullYear();
}

// ==================== END OF SCRIPT ====================
